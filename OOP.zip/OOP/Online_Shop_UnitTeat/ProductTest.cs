using Online_Shop;

namespace Online_Shop_UnitTeat
{
    [TestClass]
    public class ProductTest
    {
        private string testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "test_products.csv");

        [TestInitialize]
        public void SetUp()
        {
            // Prepare a temporary CSV file for testing
            var csvContent = "ProductId,Name,Description,Price,StockQuantity,CategoryId\n" +
                             "1,Laptop,High-end gaming laptop,1500.99,10,1\n" +
                             "2,Smartphone,Latest model smartphone,799.99,20,2";

            File.WriteAllText(testFilePath, csvContent);
        }

        [TestCleanup]
        public void CleanUp()
        {
            // Clean up the test file after tests
            if (File.Exists(testFilePath))
            {
                File.Delete(testFilePath);
            }
        }

        [TestMethod]
        public void TestLoadProductsFromFile_ShouldLoadCorrectNumberOfProducts()
        {
            // Act
            var products = Product.LoadProductsFromFile(testFilePath);

            // Assert
            Assert.AreEqual(2, products.Count, "Expected 2 products to be loaded from the CSV file.");
        }

        [TestMethod]
        public void TestLoadProductsFromFile_ShouldLoadProductDetailsCorrectly()
        {
            // Act
            var products = Product.LoadProductsFromFile(testFilePath);

            // Assert
            Assert.AreEqual(1, products[0].ProductId, "Product ID mismatch.");
            Assert.AreEqual("Laptop", products[0].Name, "Product name mismatch.");
            Assert.AreEqual("High-end gaming laptop", products[0].Description, "Product description mismatch.");
            Assert.AreEqual(1500.99, products[0].Price, "Product price mismatch.");
            Assert.AreEqual(10, products[0].StockQuantity, "Product stock quantity mismatch.");
            Assert.AreEqual(1, products[0].CategoryId, "Product category ID mismatch.");
        }

        [TestMethod]
        public void TestProductLoading_ShouldDisplayProducts()
        {
            // Redirect Console output to a string writer to capture the output for testing
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);

                // Act
                Product.TestProductLoading(testFilePath);

                // Assert
                var output = sw.ToString();
                Assert.IsTrue(output.Contains("Laptop"), "The product list should contain 'Laptop'.");
                Assert.IsTrue(output.Contains("Smartphone"), "The product list should contain 'Smartphone'.");
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSetPrice_ShouldThrowExceptionForNegativePrice()
        {
            // Act
            var product = new Product();
            product.Price = -100; // This should throw an exception
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSetStockQuantity_ShouldThrowExceptionForNegativeStock()
        {
            // Act
            var product = new Product();
            product.StockQuantity = -5; // This should throw an exception
        }

        [TestMethod]
        public void TestDefaultConstructor_ShouldSetDefaultValues()
        {
            // Act
            var product = new Product();

            // Assert
            Assert.AreEqual(0, product.ProductId, "Default ProductId mismatch.");
            Assert.AreEqual("Unknown", product.Name, "Default Name mismatch.");
            Assert.AreEqual("No description available", product.Description, "Default Description mismatch.");
            Assert.AreEqual(0.0, product.Price, "Default Price mismatch.");
            Assert.AreEqual(0, product.StockQuantity, "Default StockQuantity mismatch.");
            Assert.AreEqual(0, product.CategoryId, "Default CategoryId mismatch.");
        }

        [TestMethod]
        public void TestParameterizedConstructor_ShouldInitializeCorrectly()
        {
            // Act
            var product = new Product(1, "Laptop", "High-end gaming laptop", 1500.99, 10, 1);

            // Assert
            Assert.AreEqual(1, product.ProductId, "ProductId mismatch.");
            Assert.AreEqual("Laptop", product.Name, "Name mismatch.");
            Assert.AreEqual("High-end gaming laptop", product.Description, "Description mismatch.");
            Assert.AreEqual(1500.99, product.Price, "Price mismatch.");
            Assert.AreEqual(10, product.StockQuantity, "StockQuantity mismatch.");
            Assert.AreEqual(1, product.CategoryId, "CategoryId mismatch.");
        }
    }
}
