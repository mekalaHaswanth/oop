﻿using Online_Shop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Shop_UnitTeat
{
    [TestClass]
    public class CategoryTests
    {
        private string testFilePath;

        // Set up a test file path before each test
        [TestInitialize]
        public void SetUp()
        {
            // Create a temporary file path for testing
            testFilePath = Path.Combine(Directory.GetCurrentDirectory(), "test_categories.csv");

            // Create sample categories data
            string[] lines = new string[]
            {
                "CategoryId,Name,Description",   // Header
                "1,Electronics,Devices and gadgets",
                "2,Clothing,Apparel and fashion",
                "3,Furniture,Home and office furniture"
            };

            // Write sample data to the CSV file
            File.WriteAllLines(testFilePath, lines);
        }

        // Clean up after tests by deleting the test file
        [TestCleanup]
        public void CleanUp()
        {
            if (File.Exists(testFilePath))
            {
                File.Delete(testFilePath);
            }
        }

        [TestMethod]
        public void TestLoadCategoriesFromFile_ValidFile_ReturnsCategories()
        {
            // Arrange & Act
            var categories = Category.LoadCategoriesFromFile(testFilePath);

            // Assert
            Assert.IsNotNull(categories);
            Assert.AreEqual(3, categories.Count);
            Assert.AreEqual(1, categories[0].CategoryId);
            Assert.AreEqual("Electronics", categories[0].Name);
            Assert.AreEqual("Devices and gadgets", categories[0].Description);
        }

        [TestMethod]
        public void TestLoadCategoriesFromFile_FileNotFound_ReturnsEmptyList()
        {
            // Arrange
            string invalidFilePath = "non_existent_file.csv";

            // Act
            var categories = Category.LoadCategoriesFromFile(invalidFilePath);

            // Assert
            Assert.IsNotNull(categories);
            Assert.AreEqual(0, categories.Count);
        }

        [TestMethod]
        public void TestLoadCategoriesFromFile_InvalidData_ReturnsCorrectCategories()
        {
            // Arrange: Create a file with invalid data (missing description)
            string invalidFilePath = Path.Combine(Directory.GetCurrentDirectory(), "invalid_categories.csv");
            string[] invalidData = new string[]
            {
                "CategoryId,Name,Description",   // Header
                "1,Electronics,",
                "2,Clothing,Apparel and fashion"
            };
            File.WriteAllLines(invalidFilePath, invalidData);

            // Act: Load categories from the invalid file
            var categories = Category.LoadCategoriesFromFile(invalidFilePath);

            // Assert: Ensure data is loaded correctly (ignore missing descriptions)
            Assert.IsNotNull(categories);
            Assert.AreEqual(2, categories.Count);
            Assert.AreEqual(1, categories[0].CategoryId);
            Assert.AreEqual("Electronics", categories[0].Name);
            Assert.AreEqual("", categories[0].Description); // Empty description should be allowed
            Assert.AreEqual(2, categories[1].CategoryId);
            Assert.AreEqual("Clothing", categories[1].Name);
            Assert.AreEqual("Apparel and fashion", categories[1].Description);

            // Clean up
            File.Delete(invalidFilePath);
        }

    }

}
