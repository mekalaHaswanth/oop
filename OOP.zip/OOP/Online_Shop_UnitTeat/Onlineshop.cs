﻿using Online_Shop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Shop_UnitTeat
{
    [TestClass]
    public class ProgramTests
    {
        private Admin admin;
        private string productFilePath = @"Products_Test.csv";
        private string categoryFilePath = @"Category_Test.csv";

        [TestInitialize]
        public void TestInitialize()
        {
            // Create test data for admin
            admin = new Admin
            {
                UserName = "Admin1",
                Password = "password"
            };

            // Create test files
            if (File.Exists(productFilePath))
                File.Delete(productFilePath);
            if (File.Exists(categoryFilePath))
                File.Delete(categoryFilePath);

            File.WriteAllText(productFilePath, "ProductId,Name,Description,Price,StockQuantity,CategoryId\n");
            File.WriteAllText(categoryFilePath, "CategoryId,Name,Description\n");
        }

        [TestCleanup]
        public void TestCleanup()
        {
            if (File.Exists(productFilePath))
                File.Delete(productFilePath);
            if (File.Exists(categoryFilePath))
                File.Delete(categoryFilePath);
        }

        [TestMethod]
        public void AddNewProduct_ValidInput_ProductAdded()
        {
            // Arrange
            int productId = 1;
            string productName = "Test Product";
            string productDescription = "This is a test product.";
            double productPrice = 10.99;
            int stockQuantity = 5;
            int categoryId = 1;

            // Act
            admin.AddProductToFile(productId, productName, productDescription, productPrice, stockQuantity, categoryId, productFilePath);

            // Assert
            var lines = File.ReadAllLines(productFilePath);
            Assert.AreEqual(2, lines.Length, "The product was not added to the file.");
            Assert.IsTrue(lines[1].Contains("Test Product"), "The product name is not correct in the file.");
        }

        [TestMethod]
        public void RemoveProduct_ValidId_ProductRemoved()
        {
            // Arrange
            int productId = 1;
            admin.AddProductToFile(productId, "Test Product", "Description", 10.99, 5, 1, productFilePath);

            // Act
            admin.RemoveProductFromFile(productId, productFilePath);

            // Assert
            var lines = File.ReadAllLines(productFilePath);
            Assert.AreEqual(1, lines.Length, "The product was not removed from the file.");
        }

        [TestMethod]
        public void UpdateProduct_ValidId_ProductUpdated()
        {
            // Arrange
            int productId = 1;
            admin.AddProductToFile(productId, "Old Product", "Old Description", 10.99, 5, 1, productFilePath);
            var updatedProduct = new Product
            {
                ProductId = productId,
                Name = "Updated Product",
                Description = "Updated Description",
                Price = 15.99,
                StockQuantity = 10,
                CategoryId = 2
            };

            // Act
            admin.UpdateProductInFile(productId, productFilePath, updatedProduct);

            // Assert
            var lines = File.ReadAllLines(productFilePath);
            Assert.AreEqual(2, lines.Length, "The product was not updated in the file.");
            Assert.IsTrue(lines[1].Contains("Updated Product"), "The product name was not updated.");
        }

        [TestMethod]
        public void AddProductCategory_ValidInput_CategoryAdded()
        {
            // Arrange
            int categoryId = 1;
            string categoryName = "Test Category";
            string categoryDescription = "This is a test category.";

            // Act
            admin.AddCategoryToFile(categoryId, categoryName, categoryDescription, categoryFilePath);

            // Assert
            var lines = File.ReadAllLines(categoryFilePath);
            Assert.AreEqual(2, lines.Length, "The category was not added to the file.");
            Assert.IsTrue(lines[1].Contains("Test Category"), "The category name is not correct in the file.");
        }

        [TestMethod]
        public void UpdateProductCategory_ValidId_CategoryUpdated()
        {
            // Arrange
            int categoryId = 1;
            admin.AddCategoryToFile(categoryId, "Old Category", "Old Description", categoryFilePath);
            string newName = "Updated Category";
            string newDescription = "Updated Description";

            // Act
            admin.UpdateCategoryInFile(categoryId, newName, newDescription, categoryFilePath);

            // Assert
            var lines = File.ReadAllLines(categoryFilePath);
            Assert.AreEqual(2, lines.Length, "The category was not updated in the file.");
            Assert.IsTrue(lines[1].Contains("Updated Category"), "The category name was not updated.");
        }
    }
}
